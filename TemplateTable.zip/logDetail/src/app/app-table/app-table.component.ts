import { Component, Input } from '@angular/core';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import {} from "../app.component";
import {MatDialog} from "@angular/material/dialog";
import {DetailDialogComponent} from "../detail-dialog/detail-dialog.component";

@Component({
  selector: 'app-table',
  templateUrl: './app-table.component.html',
  styleUrls: ['./app-table.component.css'],
})

export class AppTableComponent {
  @Input() dataSource = new MatTableDataSource<Student>([
    { id: 1, name: 'Sinh Vien 3', className: 'Lop C' },
    { id: 2, name: 'Sinh Vien 2', className: 'Lop A' },
    { id: 3, name: 'Sinh Vien 1', className: 'Lop B' },
  ])
  @Input() displayedColumns: string[] = ['id', 'name', 'className'];
  constructor(private dialog: MatDialog) { }
  openDetailDialog(studentDetail: any): void {
    this.dialog.open(DetailDialogComponent, {
      width: '400px',
      position: {
        right:'10px',
        top:'10px',
        bottom:'10px',
      },
      data: studentDetail
    });
  }
}
export interface Student {
  id: number;
  name: string;
  className: string;
}


