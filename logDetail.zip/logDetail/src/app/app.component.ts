import {Component, OnInit} from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'logDetail';
  logs: Log[] = [];

  constructor(private http: HttpClient) {
  }

  ngOnInit() {
    this.http.get<Log[]>('http://localhost:8080/api/logs').subscribe(
      (response: Log[]) => {
        this.logs = response.map(log => ({
            ...log,
          full_message: log.full_message || 'N/A'
        }));
      },
      (error) => {
        console.error('Lỗi khi lấy dữ liệu:', error);
      }
    );
  }
}
interface Log {
  id: number;
  api_key: string;
  model: string;
  promt_tokens: number;
  promt_cost: number;
  completion_tokens: number;
  completion_cost: number;
  total_tokens: number;
  total_cost: number;
  full_message: string;
  promt: string;
  user_message: string;
  reply: string;
  createdAt: string;
  updatedAt: string;
}
